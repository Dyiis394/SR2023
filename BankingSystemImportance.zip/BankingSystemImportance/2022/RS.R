#循环读取文件
# #三种读写方式
# data <- read_excel("C:/XXX/1.xlsx", sheet = "Sheet1", col_names = TRUE)
# data <- read.table(file = 'manifest.tsv', sep = '\t', header = TRUE) 
# data <- read.csv('胃癌和癌前数据.csv')
# #查看当前目录文件
# list.files(pattern = "\\.tsv")    # tsv格式的数据文件
# list.files(pattern = "^C")        # 以C开头的文件
# list.files(pattern = ".tsv$")     # 以.tsv结尾的文件


#循环读取正式
lf <-list.files(pattern = "lay3.csv$") #以result开头
files <- gsub("\\.csv", "", lf)   #切掉后缀.csv，获得这些名称，为循环准备
files
lay0_result = list()
for (i in seq_along(files))
  lay0_result[[i]]=assign(files[i], read.csv(lf[i], header = F,fileEncoding = 'utf-8'))

#读取权益权重
w=read.csv("权益权重.csv", header = F)


jiaquan=matrix(data = NA,nrow = 42,ncol = 42)
for (i in 1:42) {
  n=ncol(lay0_result[[i]])
  z=cbind(lay0_result[[i]],w)
  for (j in 1:42) {
    jiaquan[j,i]=z[j,n]*z[j,n+1]
  }
}
jiaquanqiuhe=colSums(jiaquan)#包含初始冲击
#不包含初始冲击
jiaquanqiuhe2=matrix(data = NA,nrow = 42,ncol = 1)
for (i in 1:42) {
  jiaquanqiuhe2[i]=jiaquanqiuhe[i]-jiaquan[i,i]
}
jiaquanqiuhe2=as.data.frame(jiaquanqiuhe2)
library(tidyverse)
write_excel_csv(jiaquanqiuhe2,'3层RS.csv')
