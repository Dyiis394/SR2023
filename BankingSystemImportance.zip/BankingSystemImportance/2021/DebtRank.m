
%Routine for evaluating the resilience of an interbank network. The state of 
%each bank is summed up by the index h: if h=0, the bank is "healthy";
%if h=1, the bank is defaulted (which means that its equity is zero); 
%if 0<h<1, the bank is under distress (which means that its equity has 
%decreased over time, E(t)<E(t-1)) and propagates such distress through its 
%connections. As a compact measure of the "health" of the whole network, 
%the DebtRank indicator has been chosen, i.e. the weighted average of the 
%banks' h index.

function [hList,DR]=DebtRank(W0,W1,W2,W3,E0,E1,tau)

%Some banks can be in the state "default" from the beginning: in this case, 
%their equity is initialized as zero. Since, in this framework, equity can 
%only decrease, these banks remain in the state "default" throughout our 
%simulation.

W0=load('W0.txt')
W1=load('W1.txt')
W2=load('W2.txt')
W3=load('W3.txt')
E0=load("Equity.txt")
E1=load("Equity3.txt")
tau=20

N=length(E0);
h00=zeros(N,1);
h01=zeros(N,1);
h02=zeros(N,1);
h03=zeros(N,1);
for i=1:N
    if E0(i)==0
       h00(i)=1;
       h01(i)=1;
       h02(i)=1;
       h03(i)=1;
    end
end    

%Some banks can default because of first round effects, i.e. a too large
%reduction of their equity due to shocks on external assets.

h10=zeros(N,1);
h11=zeros(N,1);
h12=zeros(N,1);
h13=zeros(N,1);
for i=1:N
    if h00(i)==1
       h10(i)=1;
    else
       h10(i)=min(1,(E0(i)-E1(i))/E0(i));
    end
end
for i=1:N
    if h01(i)==1
       h11(i)=1;
    else
       h11(i)=min(1,(E0(i)-E1(i))/E0(i));
    end
end
for i=1:N
    if h02(i)==1
       h12(i)=1;
    else
       h12(i)=min(1,(E0(i)-E1(i))/E0(i));
    end
end
for i=1:N
    if h03(i)==1
       h13(i)=1;
    else
       h13(i)=min(1,(E0(i)-E1(i))/E0(i));
    end
end
Phi0=h10;
Phi1=h11;
Phi2=h12;
Phi3=h13;
hList0(:,1)=h10;
hList1(:,1)=h11;
hList2(:,1)=h12;
hList3(:,1)=h13;

%Second round effects: propagation of distress. Distress propagates through 
%the adjacency matrix: its effect is weighted by the leverage matrix 
%(i.e. the matrix of normalized assets). Leverage matrix is defined for 
%both non-defaulted banks and defaulted banks before being disconnected.
%This means that defaulted banks propagate distress just once.

e=E0/sum(E0);
h20=zeros(N,1);
h21=zeros(N,1);
h22=zeros(N,1);
h23=zeros(N,1);
DR0=zeros(1,tau);
DR1=zeros(1,tau);
DR2=zeros(1,tau);
DR3=zeros(1,tau);
for t=2:tau
    for i=1:N
        delta0=0;
        if h10(i)<1 || (h10(i)==1 && h00(i)<1)
        for j=1:N
            if h10(j)<1 || (h10(j)==1 && h00(j)<1)
               delta0=delta0+(h10(j)-h00(j))*W0(i,j)/E0(i);
            end
        end
        h20(i)=min(1,h10(i)+delta0);
        else
        h20(i)=1;
        end
    end
h00=h10;
h10=h20;
hList0(:,t)=h20;
DR0(t)=e'*(h20-Phi0);
    if sum(h20-h00)<0.0000000001
       break;
    end
end

for t=2:tau
    for i=1:N
        delta1=0;
        if h11(i)<1 || (h11(i)==1 && h01(i)<1)
        for j=1:N
            if h11(j)<1 || (h11(j)==1 && h01(j)<1)
               delta1=delta1+(h11(j)-h01(j))*W1(i,j)/E0(i);
            end
        end
        h21(i)=min(1,h11(i)+delta1);
        else
        h21(i)=1;
        end
    end
h01=h11;
h11=h21;
hList1(:,t)=h21;
DR1(t)=e'*(h21-Phi1);
    if sum(h21-h01)<0.0000000001
       break;
    end
end

for t=2:tau
    for i=1:N
        delta2=0;
        if h12(i)<1 || (h12(i)==1 && h02(i)<1)
        for j=1:N
            if h12(j)<1 || (h12(j)==1 && h02(j)<1)
               delta2=delta2+(h12(j)-h02(j))*W2(i,j)/E0(i);
            end
        end
        h22(i)=min(1,h12(i)+delta2);
        else
        h22(i)=1;
        end
    end
h02=h12;
h12=h22;
hList2(:,t)=h22;
DR2(t)=e'*(h22-Phi2);
    if sum(h22-h02)<0.0000000001
       break;
    end
end

for t=2:tau
    for i=1:N
        delta3=0;
        if h13(i)<1 || (h13(i)==1 && h03(i)<1)
        for j=1:N
            if h13(j)<1 || (h13(j)==1 && h03(j)<1)
               delta3=delta3+(h13(j)-h03(j))*W3(i,j)/E0(i);
            end
        end
        h23(i)=min(1,h13(i)+delta3);
        else
        h23(i)=1;
        end
    end
h03=h13;
h13=h23;
hList3(:,t)=h23;
DR3(t)=e'*(h23-Phi3);
    if sum(h23-h03)<0.0000000001
       break;
    end
end


csvwrite('result3_lay.csv',hList0)
csvwrite('result3_lay1.csv',hList1)
csvwrite('result3_lay2.csv',hList2)
csvwrite('result3_lay3.csv',hList3)
