#三、计算银行i对银行j的影响矩阵
#导入数据
assetdata = read.csv("银行资产矩阵2021.csv" , header=TRUE)
equitydata = read.csv("Equity.txt" , header=F)

asset = assetdata[,c(-1,-2)]
asset[is.na(asset)]<-0#缺失值替换为0

#asset[,c(1:21)] <- as.numeric(unlist(asset[,c(1:21)]))

assetdata2 = asset * 0.000001

equity = list()
for (i in 1:21) {
  equity[[i]] = equitydata - assetdata2[1:42,i]*0.1
  for (j in 1:42) {
    if (equity[[i]][j,1]<0)
    {
      equity[[i]][j,1]=0
    }
  }
}
#输出list
txtfile = paste(0:21,".txt",sep="")
# for (i in 1:21) {
#   equity[[i]]=paste(txtfile[i],sep="")
#   write.csv()
# }
# 
# library(aqp)
# for (i in 1:21) {
#   sink(txtfile[i])
#   equity[[1]]
#   sink()
# }

for (i in 0:20) {
  x=equity[[i+1]]
  write.table(x,txtfile[i+1],sep=',',row.names = F,col.names = F)
}